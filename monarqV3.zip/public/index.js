/* eslint-disable no-unused-expressions */
/* eslint-disable import/extensions */
import React from "react";
import ReactDOM from "react-dom";
import App from "../components/App.jsx";
import "core-js/stable";

require("regenerator-runtime/path").path;

ReactDOM.render(<App />, document.getElementById("root"));
